"""
To run this script:

1. Open the terminal in the ramulator folder
2. run "python3 script.py"
3. Enter the cpu trace file name when prompted
4. The reuslts will be saved in out.csv in the ramulator folder

"""

import csv
import subprocess
import os
from itertools import zip_longest
import re


config_DDR4 ="configs/DDR4-config.cfg"
config_HBM ="configs/HBM-config.cfg"
config_PCM ="configs/PCM-config.cfg"

trace_files=[]
txtfiles=[]
maxfile= 5
while len(trace_files)<maxfile:
    trace_f = input("Enter the file name: ")
    trace_files.append(trace_f)
    cmd1 = "./ramulator %s --mode=cpu --stats output_DDR4_%s.txt %s" %(config_DDR4, trace_f, trace_f)
    p1 = subprocess.run(cmd1, shell=True)
    txtfiles.append("output_DDR4_"+trace_f+".txt")
    cmd3 = "./ramulator %s --mode=cpu --stats output_HBM_%s.txt %s" %(config_HBM, trace_f, trace_f)
    p3 = subprocess.run(cmd3, shell=True)
    txtfiles.append("output_HBM_"+trace_f+".txt")
    cmd2 = "./ramulator %s --mode=cpu --stats output_PCM_%s.txt %s" %(config_PCM, trace_f, trace_f)
    p2 = subprocess.run(cmd2, shell=True)
    txtfiles.append("output_PCM_"+trace_f+".txt")

cpu_cycle = []
record_cycs=[]
pt_access=[]
read_trans=[]
write_trans=[]
dram_cycs=[]
ac_cycs=[]
bu_cycs=[]
in_req=[]
file_name=[]


for file in txtfiles:

    file_name.append(file)
    with open( file , 'r') as in_file:
        for line in in_file:
            words = line.split('#')
            if 'ramulator.cpu_cycles' in line:
                data = line.split('ramulator.cpu_cycles')[1].strip()
                temp = data.index('#')
                res = data[:temp]
                row = res.strip()
                cpu_cycle.append(row)

            elif 'ramulator.record_cycs_core_0' in line:
                data = line.split('ramulator.record_cycs_core_0')[1].strip()
                temp = data.index('#')
                res = data[:temp]
                row = res.strip()
                record_cycs.append(row)

            elif 'ramulator.page_table_access' in line:
                data = line.split('ramulator.page_table_access')[1].strip()
                temp = data.index('#')
                res = data[:temp]
                row = res.strip()
                pt_access.append(row)

            elif 'ramulator.read_transaction_bytes_0' in line:
                data = line.split('ramulator.read_transaction_bytes_0')[1].strip()
                temp = data.index('#')
                res = data[:temp]
                row = res.strip()
                read_trans.append(row)

            elif 'ramulator.write_transaction_bytes_0' in line:
                data = line.split('ramulator.write_transaction_bytes_0')[1].strip()
                temp = data.index('#')
                res = data[:temp]
                row = res.strip()
                write_trans.append(row)

            elif 'ramulator.dram_cycles' in line:
                data = line.split('ramulator.dram_cycles')[1].strip()
                temp = data.index('#')
                res = data[:temp]
                row = res.strip()
                dram_cycs.append(row)

            elif 'ramulator.ramulator_active_cycles' in line:
                data = line.split('ramulator.ramulator_active_cycles')[1].strip()
                temp = data.index('#')
                res = data[:temp]
                row = res.strip()
                ac_cycs.append(row)

            elif 'ramulator.ramulator_active_cycles' in line:
                data = line.split('ramulator.ramulator_active_cycles')[1].strip()
                temp = data.index('#')
                res = data[:temp]
                row = res.strip()
                bu_cycs.append(row)

            elif 'ramulator.incoming_requests_per_channel' in line:
                data = line.split('ramulator.incoming_requests_per_channel')[1].strip()
                temp = data.index('#')
                res = data[:temp]
                row = res.strip()
                in_req.append(row)

               
          


csv_out = open('out.csv', 'w', newline='')
writer = csv.writer(csv_out)
writer.writerow(['file_name','ramulator.cpu_cycles','ramulator.record_cycs_core_0','ramulator.page_table_access','ramulator.read_transaction_bytes_0','ramulator.write_transaction_bytes_0','ramulator.dram_cycles','ramulator.ramulator_active_cycles_0','ramulator.busy_cycles_0','ramulator.incoming_requests'])
for x,a, b,c,d,e,f,g,h,i in zip_longest(file_name,cpu_cycle, record_cycs,pt_access,read_trans,write_trans,dram_cycs,ac_cycs,bu_cycs,in_req):
        writer.writerow([x,a, b,c,d,e,f,g,h,i])

